# Szperacz
Project for the subject of software engineering.
